<?php
// Récupère les données envoyées en POST et les décode en tableau associatif PHP
$data = json_decode(file_get_contents('php://input'), true);

// Récupère l'index du QCM auquel l'utilisateur a répondu et les réponses données
$index = intval($data['qcmIndex']);  // Convertit l'index en entier
$answers = $data['answers'];  // Récupère les réponses de l'utilisateur

// Charge le fichier JSON contenant tous les QCMs
$qcms = json_decode(file_get_contents('../assets/data/qcm.json'), true);

// Récupère le QCM spécifique en fonction de l'index
$qcm = $qcms[$index];

// Initialise le score de l'utilisateur
$score = 0;

// Calcule le nombre total de questions dans ce QCM
$total = count($qcm['questions']);

// Parcours chaque question du QCM
foreach ($qcm['questions'] as $i => $question) {
    // Récupère les réponses correctes pour cette question
    $correct = $question['bonnes'];
    
    // Récupère les réponses données par l'utilisateur pour cette question
    $user = $answers["q{$i}"] ?? [];  // Si aucune réponse n'est donnée, un tableau vide est utilisé

    // Trie les réponses (important pour comparer indépendamment de l'ordre des réponses)
    sort($correct);
    sort($user);

    // Compare les réponses correctes et celles de l'utilisateur
    if ($correct == $user) {
        $score++;  // Si elles sont identiques, augmente le score
    }
}

// Calcule le pourcentage de bonnes réponses
$percentage = round(($score / $total) * 100);

// Retourne le score sous forme JSON
echo json_encode(['score' => $percentage]);
?>
